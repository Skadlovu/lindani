import io
import qrcode
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from django.conf import settings
from collections import defaultdict
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, HRFlowable
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from PIL import Image as PilImage, ImageDraw
from django.utils import timezone
from.models import TicketHolder

# Function to overlay the logo in the center of the QR code
def generate_barcode(ticket_id):
    qr = qrcode.QRCode(version=7, box_size=10, border=5)
    qr.add_data(str(ticket_id))
    qr.make(fit=True)
    qr_image = qr.make_image(fill_color="black", back_color="white")

    # Open the logo and resize it
    logo_path = 'kona/static/img/logo.png'
    logo = PilImage.open(logo_path)
    logo = logo.convert("RGBA")
    logo_size = 200  # Size for the logo
    logo.thumbnail((logo_size, logo_size))

    # Get QR image size and position the logo in the center
    qr_image = qr_image.convert("RGBA")
    qr_width, qr_height = qr_image.size
    logo_pos = ((qr_width - logo_size) // 2, (qr_height - logo_size) // 2)

    # Paste the logo onto the QR code
    qr_image.paste(logo, logo_pos, mask=logo)

    # Save the result into a buffer
    img_buffer = io.BytesIO()
    qr_image.save(img_buffer, format='PNG')
    img_buffer.seek(0)

    return img_buffer

# Modern ticket PDF creation function
def create_ticket_pdf(ticket):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=landscape(letter))
    elements = []

    # Define colors
    dark_green = colors.Color(0.18, 0.49, 0.196)  # #2E7D32
    light_green = colors.Color(0.945, 0.973, 0.914)  # #F1F8E9

    # Custom styles
    title_style = ParagraphStyle(
        name='Title',
        fontSize=24,
        alignment=TA_CENTER,
        textColor=dark_green,
        spaceAfter=30,
        borderColor=dark_green,
        borderWidth=3,
        borderPadding=20
    )

    info_style = ParagraphStyle(
        name='Info',
        fontSize=12,
        alignment=TA_LEFT,
        textColor=colors.black,
        leftIndent=50,
        spaceAfter=10
    )

    # Create the main title with bottom border
    elements.append(Paragraph(ticket['event'], title_style))
    elements.append(HRFlowable(
        width="100%",
        thickness=2,
        color=dark_green,
        spaceAfter=20,
        vAlign='BOTTOM',
    ))
    ticket_date = timezone.now()

# Create two-column layout
    info_data = [
    ['Name:', ticket['name']],
    ['Surname:', ticket['surname']],
    ['Event Date:', ticket['event_date']],
    ['Event Time:', ticket['event_time']],
    ['Ticket Type:', ticket['ticket_type']],
    ['Ticket Price:', f"R {ticket['price']:.2f}"],
    ['Ticket Date:', ticket_date.strftime('%Y-%m-%d %H:%M:%S')]
    ]

    # Calculate column widths
    available_width = landscape(letter)[0] - 100
    col_width = available_width / 2

    # Create table for left column information
    left_table = Table(info_data, colWidths=[100, col_width-100])
    left_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (0, -1), 'LEFT'),
        ('ALIGN', (1, 0), (1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 12),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 15),
        ('TEXTCOLOR', (0, 0), (0, -1), dark_green),  # Green labels
        ('BACKGROUND', (0, 0), (-1, -1), light_green),  # Light green background
        ('GRID', (0, 0), (-1, -1), 0.5, colors.white),  # White grid lines
        ('ROUNDEDCORNERS', [10, 10, 10, 10]),
    ]))

    # Generate QR code for right column with logo in center
    barcode_buffer = generate_barcode(ticket['id'])
    qr_image = Image(barcode_buffer, width=2.5*inch, height=2.5*inch)

    # QR code container with green border
    qr_container = [
        [Spacer(1, 30)],
        [qr_image],
        [Paragraph("Scan for Entry", ParagraphStyle(
            'QRLabel',
            alignment=TA_CENTER,
            textColor=dark_green,
            fontSize=14,
            fontName='Helvetica-Bold'
        ))]
    ]
    right_table = Table(qr_container)
    right_table.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 2, dark_green),
        ('BACKGROUND', (0, 0), (-1, -1), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))

    # Combine left and right columns with vertical separator
    main_table = Table([
        [left_table, right_table]
    ], colWidths=[col_width, col_width])

    main_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LINEAFTER', (0, 0), (0, 0), 2, dark_green),  # Vertical separator
    ]))

    elements.append(main_table)

    # Add logo at the bottom of the ticket
    logo_image = Image('kona/static/img/logo.png', width=1*inch, height=1*inch)
    elements.append(Spacer(1, 20))
    elements.append(logo_image)

    # Add green footer line
    elements.append(Spacer(1, 20))
    elements.append(HRFlowable(
        width="100%",
        thickness=8,
        color=dark_green,
        spaceBefore=20
    ))

    # Build the PDF
    doc.build(elements)
    buffer.seek(0)
    return buffer

def send_tickets(ticket_sale):
    tickets_by_event = defaultdict(list)
    pdf_attachments = []

    for holder in ticket_sale.ticket_holders.all():
        ticket_info = {
            'id': holder.id,
            'name': holder.name,
            'surname': holder.surname,
            'event': holder.ticket_details.event.title,
            'ticket_type': holder.ticket_details.class_name,
            'price': holder.price,
            'event_date': holder.ticket_details.event.event_date,
            'event_time': holder.ticket_details.event.event_time
        }
        tickets_by_event[holder.ticket_details.event.title].append(ticket_info)

        # Generate PDF for this ticket
        pdf_buffer = create_ticket_pdf(ticket_info)
        pdf_attachments.append((f"ticket_{holder.id}.pdf", pdf_buffer.getvalue(), 'application/pdf'))

    # Render the email template
    email_body = render_to_string('ticket/ticket_email.html', {
        'tickets_by_event': dict(tickets_by_event),
        'total_price': ticket_sale.total_price,
    })

    # Create and send the email
    subject_line = f'Your tickets for {", ".join(tickets_by_event.keys())}'
    email = EmailMessage(
        subject=subject_line,
        body=email_body,
        from_email=settings.DEFAULT_FROM_EMAIL,
        to=[ticket_sale.customer.user.email],
    )
    email.content_subtype = "html"

    # Attach PDF tickets
    for attachment in pdf_attachments:
        email.attach(*attachment)

    email.send(fail_silently=False)

# Modified version to handle multiple ticket sales
def send_tickets_for_purchase(customer_email, ticket_sales):
    tickets_by_event = defaultdict(list)
    pdf_attachments = []
    total_price = 0

    # Process each ticket sale (one per event)
    for ticket_sale in ticket_sales:
        total_price += ticket_sale.total_price

        for holder in ticket_sale.ticket_holders.all():
            ticket_info = {
                'id': holder.id,
                'name': holder.name,
                'surname': holder.surname,
                'event': ticket_sale.event.title,  # Now using ticket_sale.event
                'ticket_type': holder.ticket_details.class_name,
                'price': holder.price,
                'event_date': ticket_sale.event.event_date,
                'event_time': ticket_sale.event.event_time
            }
            tickets_by_event[ticket_sale.event.title].append(ticket_info)

            # Generate PDF for this ticket
            pdf_buffer = create_ticket_pdf(ticket_info)
            pdf_attachments.append((
                f"ticket_{holder.id}_{ticket_sale.event.title}.pdf",
                pdf_buffer.getvalue(),
                'application/pdf'
            ))

    # Render the email template with all tickets
    email_body = render_to_string('ticket/ticket_email.html', {
        'tickets_by_event': dict(tickets_by_event),
        'total_price': total_price,
        'multiple_events': len(ticket_sales) > 1
    })

    # Create and send the email with all tickets
    subject_line = f'Your tickets for {", ".join(tickets_by_event.keys())}'
    email = EmailMessage(
        subject=subject_line,
        body=email_body,
        from_email=settings.DEFAULT_FROM_EMAIL,
        to=[customer_email],
    )
    email.content_subtype = "html"

    # Attach all PDF tickets
    for attachment in pdf_attachments:
        email.attach(*attachment)

    email.send(fail_silently=False)