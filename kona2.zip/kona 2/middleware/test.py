from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from cart.models import CartItem
from ticket.models import TicketHolder
from customer.models import Customer
from decimal import Decimal

class TicketholderInfoMiddlewareTest(TestCase):
    def setUp(self):
        # Set up client and user data
        self.client = Client()
        self.user = User.objects.create_user(username='testuser', password='password')
        self.customer = Customer.objects.create(user=self.user)

        # Sample ticket details and cart item
        self.ticket_details = TicketHolder.objects.create(
            name="Sample Ticket",
            surname="Sample Ticket",
            price=Decimal("50.00")
        
        )

    def test_redirect_to_ticketholder_info_if_needed(self):
        """
        Test that authenticated users with incomplete ticketholder info are redirected.
        """
        # Log in the user and add a cart item for testing
        self.client.login(username='testuser', password='password')
        CartItem.objects.create(customer=self.customer, ticket_details=self.ticket_details, quantity=2)

        # Access a non-exempt path, expecting a redirect to collect ticketholder info
        response = self.client.get(reverse('some_non_exempt_view'))
        self.assertRedirects(response, reverse('cart:collect_ticketholder_info'))

    def test_no_redirect_if_ticketholder_info_filled(self):
        """
        Test that authenticated users with ticketholder info do not get redirected.
        """
        # Log in the user and add a cart item
        self.client.login(username='testuser', password='password')
        CartItem.objects.create(customer=self.customer, ticket_details=self.ticket_details, quantity=2)

        # Set session data as if ticketholder info was filled
        session = self.client.session
        session['ticketholders'] = [{'name': 'John', 'surname': 'Doe', 'ticket_id': self.ticket_details.id}]
        session.save()

        # Access a non-exempt path, expecting no redirect
        response = self.client.get(reverse('some_non_exempt_view'))
        self.assertEqual(response.status_code, 200)

    def test_no_redirect_for_exempt_paths(self):
        """
        Test that login and logout views are not redirected by middleware.
        """
        # Access the login view while authenticated, expecting no redirect
        response = self.client.get(reverse('account:login'))
        self.assertEqual(response.status_code, 200)

        # Access the logout view while authenticated, expecting no redirect
        response = self.client.get(reverse('account:logout'))
        self.assertEqual(response.status_code, 200)

    def test_unauthenticated_user_no_redirect(self):
        """
        Test that unauthenticated users are not redirected by middleware.
        """
        # Access a non-exempt view as an unauthenticated user
        response = self.client.get(reverse('some_non_exempt_view'))
        self.assertEqual(response.status_code, 200)
