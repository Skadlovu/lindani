from datetime import datetime, timedelta
from .models import Organiser
from .views import generate_sales_report

def generate_daily_sales_report():
    now = datetime.now()
    start_time = now - timedelta(days=1, hours=23, minutes=59)  # 9:01 AM previous day
    end_time = now - timedelta(minutes=1)  # 8:59 AM current day

    organisers = Organiser.objects.all()
    for organiser in organisers:
        generate_sales_report(organiser, start_time, end_time)
