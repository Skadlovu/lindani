from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import CartItem,Cart
from django.shortcuts import render
from django.http import JsonResponse,HttpResponse
from ticket.models import TicketSales,TicketHolder,TicketDetails
from django.conf import settings
from.forms import AddToCartForm,TicketHolderForm,CreditCheckForm
import hashlib
from django.views.decorators.csrf import csrf_exempt
import urllib.parse
import logging
from django.urls import reverse
from ticket.forms import TicketHolderFormSet
from ticket.utils import send_tickets_for_purchase
from django.contrib import messages
from django.core.exceptions import ValidationError
from decimal import Decimal
from django.db import transaction
from.services import CartService
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Sum, F
from django.views.decorators.http import require_http_methods
from django.views.generic import View
from .utils import generate_payfast_signature as generate_signature
from customer.models import Customer
from .utils import fetch_social_media_data,reassess_creditworthiness,store_creditworthiness_score,setup_payfast_recurring_payment
from event.models import Event
from django.utils import timezone
from django.views.decorators.http import require_POST
import json






logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)


def generate_signature(payfast_data, passphrase=None):
# Define the expected order of the keys as per PayFast documentation
    ordered_keys = [
        'merchant_id', 'merchant_key', 'return_url', 'cancel_url', 'notify_url',
         'amount', 'item_name'
    ]
    
    # Create parameter string in the specified order
    pf_output = ''
    for key in ordered_keys:
        if key in payfast_data and payfast_data[key] != '':
            pf_output += f'{key}={urllib.parse.quote(str(payfast_data[key]).strip())}&'
    
    # Remove the last ampersand
    get_string = pf_output[:-1]
    
    # Append passphrase if provided
    if passphrase:
        get_string += f'&passphrase={urllib.parse.quote(passphrase.strip())}'
    
    # Log the string before hashing
    logger.debug(f"String to hash: {get_string}")
    
    # Generate and return MD5 hash of the final string
    signature = hashlib.md5(get_string.encode('utf-8')).hexdigest()
    
    # Log the generated signature
    logger.debug(f"Generated Signature: {signature} (Length: {len(signature)})")
    
    return signature

from django.urls import NoReverseMatch

@login_required
def checkout(request):
    cart = Cart.get_cart(request)

    
    if not cart.items.exists():
        messages.warning(request, "Your cart is empty.")
        return redirect('cart:view_cart')
    
    ticketholders = request.session.get('ticketholders')
    if not ticketholders:
        messages.error(request, "Please provide ticketholder information first.")
        return redirect('cart:collect_ticketholder_info')
    
    total_price = cart.total_price
    first_item = cart.items.first()
    item_name = f"{first_item.ticket_details.event.title} - {cart.items.count()} ticket(s)"
    
    # Preparing PayFast data dictionary
    payfast_data = {
        'merchant_id': settings.PAYFAST_MERCHANT_ID,
        'merchant_key': settings.PAYFAST_MERCHANT_KEY,
        'amount': f'{total_price:.2f}',
        'item_name': item_name,
        'name_first': request.user.first_name,
        'name_last': request.user.last_name,
        'email_address': request.user.email,
        'custom_str1': str(cart.id),
        'm_payment_id': f'CART_{cart.id}_{timezone.now().strftime("%Y%m%d%H%M%S")}'
    }

    try:
        # Log return_url, cancel_url, notify_url generation
        payfast_data['return_url'] = request.build_absolute_uri(reverse('cart:success'))
        logger.info(f"Return URL: {payfast_data['return_url']}")
        
        payfast_data['cancel_url'] = request.build_absolute_uri(reverse('cart:cancel'))
        logger.info(f"Cancel URL: {payfast_data['cancel_url']}")
        
        payfast_data['notify_url'] = request.build_absolute_uri(reverse('cart:notify'))
        logger.info(f"Notify URL: {payfast_data['notify_url']}")

        # Log for potential settings or signature issues
        logger.info(f"PayFast merchant ID: {payfast_data['merchant_id']}")
        
        # Generate and log the signature
        signature = generate_signature(payfast_data, passphrase=settings.PAYFAST_PASSPHRASE)
        logger.info(f"Generated signature: {signature}")

        logger.info(
            "Initiating PayFast payment",
            extra={
                'cart_id': cart.id,
                'user_id': request.user.id,
                'amount': total_price,
                'item_count': cart.items.count()
            }
        )
        
        request.session['payment_data'] = {
            'cart_id': cart.id,
            'amount': str(total_price),
            'ticketholders': ticketholders
        }

        return render(request, 'cart/checkout.html', {
            'cart_items': cart.items.all(),
            'total_price': total_price,
            'payfast_data': payfast_data,
            'signature': signature,
            'payfast_url': settings.PAYFAST_URL
        })
        
    except NoReverseMatch as e:
        logger.error("Reverse match error for URLs: Check URL names in the `reverse()` calls.", exc_info=True)
        messages.error(request, "There was an error with the checkout URLs. Please contact support.")
        return redirect('cart:view_cart')
        
    except KeyError as e:
        logger.error(f"KeyError in settings or payfast_data: Missing key {str(e)}", exc_info=True)
        messages.error(request, "An internal error occurred. Please try again later.")
        return redirect('cart:view_cart')
        
    except Exception as e:
        logger.error(f"Error preparing checkout: {str(e)}", exc_info=True)
        messages.error(request, "An error occurred while preparing your checkout. Please try again.")
        return redirect('cart:view_cart')


@login_required
def payment_success(request):
    customer = get_object_or_404(Customer, user=request.user)
    cart_items = CartItem.objects.filter(cart__user=request.user)
    total_price = sum(item.ticket_details.price * item.quantity for item in cart_items)
    ticketholders = request.session.get('ticketholders', [])

    if not ticketholders:
        messages.error(request, "No ticketholder information found. Please try again.")
        return redirect('cart:cart_view')

    with transaction.atomic():
        # Group cart items by event
        event_items = {}
        for item in cart_items:
            event = item.ticket_details.event
            if event.id not in event_items:
                event_items[event.id] = {
                    'event': event,
                    'organiser': event.organiser,
                    'items': [],
                    'subtotal': 0
                }
            event_items[event.id]['items'].append(item)
            event_items[event.id]['subtotal'] += item.ticket_details.price * item.quantity

        ticketholder_index = 0
        all_ticket_sales = []
        
        # Create separate TicketSales for each event
        for event_id, event_data in event_items.items():
            ticket_sale = TicketSales.objects.create(
                customer=customer,
                organiser=event_data['organiser'],
                total_price=event_data['subtotal'],
                event=event_data['event'],
                purchase_date=timezone.now()
            )
            all_ticket_sales.append(ticket_sale)

            # Process items for this event
            for item in event_data['items']:
                availability = item.ticket_details.availability

                # Check ticket availability
                if availability.tickets_remaining < item.quantity:
                    messages.error(
                        request,
                        f"Not enough {item.ticket_details.class_name} tickets available for {event_data['event'].title}."
                    )
                    raise transaction.TransactionRollback()

                # Create ticket holders for this item
                for _ in range(item.quantity):
                    if ticketholder_index >= len(ticketholders):
                        messages.error(request, "Not enough ticketholder information for all tickets.")
                        raise transaction.TransactionRollback()

                    holder_data = ticketholders[ticketholder_index]
                    ticketholder_index += 1

                    if not holder_data.get('name') or not holder_data.get('surname'):
                        messages.error(request, "Missing required ticketholder information.")
                        raise transaction.TransactionRollback()

                    TicketHolder.objects.create(
                        ticket_sales=ticket_sale,
                        ticket_details=item.ticket_details,
                        name=holder_data['name'],
                        surname=holder_data['surname'],
                        price=item.ticket_details.price
                    )

                # Update availability
                availability.sold += item.quantity
                if availability.sold >= availability.quantity:
                    availability.available = False
                availability.save()
    

        # Send tickets for each sale
        send_tickets_for_purchase(
        customer_email=customer.user.email,
        ticket_sales=all_ticket_sales
        )

        # Cleanup
        cart_items_data = list(cart_items)
        cart_items.delete()
        request.session.pop('ticketholders', None)
        request.session.pop('payment_data', None)

        return render(request, 'cart/success.html', {
            'customer': customer,
            'cart_items': cart_items_data,
            'ticket_sales': all_ticket_sales,  # Pass all sales to template
            'total_price': total_price  # Pass overall total
        })


@login_required
def payment_cancel(request):
    return render(request, 'cart/purchase_failed.html')


def payment_notify(request):
    return JsonResponse({'status': 'IPN received'})




def add_to_cart(request, ticket_details_id, quantity):
    ticket_details = get_object_or_404(TicketDetails, id=ticket_details_id)
    
    try:
        with transaction.atomic():
            cart = Cart.get_cart(request)
            cart_item, created = cart.items.get_or_create(
                ticket_details=ticket_details,
                defaults={'quantity': quantity}
            )
            
            if not created:
                cart_item.quantity += quantity
                cart_item.save()
            
            cart_totals = {
                'cart_count': cart.items.aggregate(total=Sum('quantity'))['total'] or 0,
                'total_price': cart.total_price  # Ensure cart.total_price calculates correctly in Cart model
            }
            
            return cart_totals
            
    except Exception as e:
        raise ValidationError(f"Error adding tickets to cart: {str(e)}")
    


def cart_view(request):
    cart = Cart.get_cart(request)
    return render(request, 'cart/cart.html', {
        'cart_items': cart.items.all(),
        'total_price': cart.total_price,
    })

@login_required
def collect_ticketholder_info(request):
    cart = Cart.get_cart(request)
    
    if not cart.items.exists():
        messages.warning(request, "Your cart is empty.")
        return redirect('cart:cart_view')

    cart_with_ranges = [{'item': item, 'range': range(item.quantity)} for item in cart.items.all()]

    if request.method == 'POST':
        ticketholders = []
        for item in cart.items.all():
            for i in range(item.quantity):
                name = request.POST.get(f'ticket_{item.ticket_details.id}_name_{i}')
                surname = request.POST.get(f'ticket_{item.ticket_details.id}_surname_{i}')
                
                if not name or not surname:
                    messages.error(request, "Please fill in all ticketholder information.")
                    return redirect('cart:collect_ticketholder_info')
                
                ticketholders.append({
                    'name': name,
                    'surname': surname,
                    'ticket_id': item.ticket_details.id
                })
        
        request.session['ticketholders'] = ticketholders
        return redirect('cart:cash_payment')

    return render(request, 'cart/ticket_holder_form.html', {
        'cart_with_ranges': cart_with_ranges
    })



@require_POST
def update_cart_quantity(request):
    try:
        data = json.loads(request.body)
        item_id = data.get('item_id')
        quantity = data.get('quantity')
        
        cart = Cart.get_cart(request)
        cart_item = cart.items.get(id=item_id)
        
        # Update quantity
        cart_item.quantity = quantity
        cart_item.save()
        
        # Calculate new totals using stored price
        item_subtotal = cart_item.total_price
        
        return JsonResponse({
            'success': True,
            'item_subtotal': item_subtotal,
            'cart_total': cart.total_price,
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=400)

@require_POST
def remove_cart_item(request):
    try:
        data = json.loads(request.body)
        item_id = data.get('item_id')
        
        cart = Cart.get_cart(request)
        cart_item = cart.items.get(id=item_id)
        cart_item.delete()
        
        return JsonResponse({
            'success': True,
            'cart_total': cart.total_price,
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=400)





def prompt_view(request):
    return render(request, 'cart/prompt.html')

@login_required
def choose_payment_method(request):
    if request.method == 'POST':
        payment_method = request.POST.get('payment_method')
        if payment_method == 'cash':
            return redirect('cart:cash_payment')
        elif payment_method == 'credit':
            return redirect('cart:credit_check')
    
    
    return render(request, 'cart/choose_payment.html')

@login_required
def credit_check(request):
    customer = get_object_or_404(Customer, user=request.user)

    if request.method == 'POST':
        form = CreditCheckForm(request.POST, request.FILES)
        if form.is_valid():
            total_income = form.cleaned_data['total_income']
            total_expenses = form.cleaned_data['total_expenses']
            facebook_profile = form.cleaned_data['facebook_profile']
            twitter_profile = form.cleaned_data['twitter_profile']
            instagram_profile = form.cleaned_data['instagram_profile']
            payslip = form.cleaned_data['payslip']
            
            # Handle the uploaded payslip file here
            # Example: save the payslip to the customer's profile
            customer.payslip = payslip
            customer.save()

            # Fetch social media data based on the provided URLs
            social_media_posts = fetch_social_media_data(
                customer.user, 
                facebook_profile, 
                twitter_profile, 
                instagram_profile
            )
            
            existing_score = reassess_creditworthiness(customer.user)
            
            if existing_score == "Please update your financial and social media information for reassessment.":
                credit_score = store_creditworthiness_score(customer.user, total_income, total_expenses, social_media_posts)
            else:
                credit_score = existing_score
            
            if credit_score >= 75:
                return render(request, 'cart/credit_details.html', {'credit_score': credit_score})
            else:
                return render(request, 'cart/credit_denied.html', {'credit_score': credit_score})
    else:
        form = CreditCheckForm()
    
    return render(request, 'cart/credit_check.html', {'form': form})

@login_required
def credit_details(request, event_id):
    if request.method == 'POST':
        duration = int(request.POST.get('duration'))
        card_number = request.POST.get('card_number')
        card_expiry = request.POST.get('card_expiry')
        card_cvv = request.POST.get('card_cvv')
        
        event = get_object_or_404(Event, pk=event_id)
        customer = get_object_or_404(Customer, user=request.user)
        
        ticket = TicketSales.objects.create(
            customer=customer,
            event=event,
            payment_method='credit',
            credit_duration=duration,
            card_number=card_number,
            card_expiry=card_expiry,
            card_cvv=card_cvv
        )
        
        payfast_response = setup_payfast_recurring_payment(ticket)
        
        if payfast_response.get('success'):
            return render(request, 'cart/purchase_success.html')
        else:
            ticket.delete()
            return render(request, 'cart/purchase_failed.html')
    
    return render(request, 'cart/credit_details.html')




@csrf_exempt
def payfast_notify(request):
    if request.method == 'POST':
        payfast_order = request.POST

        if payfast_order['payment_status'] == 'COMPLETE':
            # Process the completed payment
            amount = payfast_order['amount_gross']
            transaction_id = payfast_order['m_payment_id']

            # You can add your logic here to confirm payment and update your records
            # For example, marking the TicketSales as paid
            ticket_sales = TicketSales.objects.filter(transaction_id=transaction_id).update(paid=True)
            return HttpResponse(status=200)
        else:
            return HttpResponse('Payment failed', status=400)
    return HttpResponse(status=405)
