from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from django.db.models.signals import post_save
from django.core.exceptions import ValidationError
from django.dispatch import receiver
from decimal import Decimal
from .models import CartItem
from customer.models import Customer
from ticket.models import TicketDetails,TicketHolder
from .signals import transfer_cart_on_login
from event.models import Event
from organiser.models import Organiser


class CartFeaturesTest(TestCase):
    def setUp(self):
        # Set up client and create a test user
        self.client = Client()
        self.user = User.objects.create_user(username='testuser', password='password')
        self.client.login(username='testuser', password='password')
        
        # Create an organiser associated with the user
        self.organiser = Organiser.objects.create(user=self.user)
        
        # Create a sample event associated with the organiser
        self.event = Event.objects.create(
            title="Sample Event",
            description="This is a test event",
            organiser=self.organiser,
            slug="sample-event",
            event_date="2024-10-27",
            venue="Test Venue",
            event_time="18:00"
        )

        # Create ticket details for the event
        self.ticket_details = TicketDetails.objects.create(
            class_name="Sample Ticket",
            price=Decimal("50.00"),
            number_of_tickets=5,
            event=self.event
        )

        # Create a customer for the user
        self.customer = Customer.objects.create(user=self.user)

        # Create a ticketholder associated with ticket_details
        self.ticketholder = TicketHolder.objects.create(
            ticket_details=self.ticket_details,
            name="John",
            surname="Doe"
        )


    def test_collect_ticketholder_info_redirects_when_needed(self):
        """
        Test that `collect_ticketholder_info` redirects when ticketholder information is missing.
        """
        # Add an item to the user's cart
        CartItem.objects.create(customer=self.customer, ticket_details=self.ticket_details, quantity=2)
        
        # Access the ticketholder info view and expect a redirect to fill in ticketholder info
        response = self.client.get(reverse('cart:collect_ticketholder_info'))
        self.assertEqual(response.status_code, 200)  # Form page should be accessible

        # Submit the form without filling required ticketholder info, expect redirect back to form
        response = self.client.post(reverse('cart:collect_ticketholder_info'), data={})
        self.assertRedirects(response, reverse('cart:collect_ticketholder_info'))

        # Submit the form with ticketholder information
        response = self.client.post(reverse('cart:collect_ticketholder_info'), data={
            f'ticket_{self.ticket_details.id}_name_0': 'John',
            f'ticket_{self.ticket_details.id}_surname_0': 'Doe',
            f'ticket_{self.ticket_details.id}_name_1': 'Jane',
            f'ticket_{self.ticket_details.id}_surname_1': 'Doe'
        })
        self.assertRedirects(response, reverse('cart:cash_payment'))
        
        # Check that ticketholders are stored in session
        ticketholders = self.client.session.get('ticketholders')
        self.assertEqual(len(ticketholders), 2)

    def test_add_to_cart_authenticated_user(self):
        """
        Test that `add_to_cart` adds items correctly for authenticated users.
        """
        response = self.client.post(reverse('cart:add_to_cart'), data={
            'ticket_details_id': self.ticket_details.id,
            'quantity': 3
        })
        
        # Fetch updated cart information
        cart_items = CartItem.objects.filter(customer=self.customer)
        self.assertEqual(cart_items.count(), 1)
        self.assertEqual(cart_items[0].quantity, 3)
        
        # Test the response for cart count and total price
        cart_totals = response.json()
        self.assertEqual(cart_totals['cart_count'], 3)
        self.assertEqual(cart_totals['total_price'], Decimal('150.00'))  # 3 * 50.00

    def test_add_to_cart_unauthenticated_user(self):
        """
        Test that `add_to_cart` adds items correctly for unauthenticated users using session.
        """
        # Log out the user
        self.client.logout()
        
        response = self.client.post(reverse('cart:add_to_cart'), data={
            'ticket_details_id': self.ticket_details.id,
            'quantity': 2
        })
        
        # Retrieve cart items by session key instead of customer
        session_key = self.client.session.session_key
        cart_items = CartItem.objects.filter(session_key=session_key)
        
        # Assert cart item is created for the session
        self.assertEqual(cart_items.count(), 1)
        self.assertEqual(cart_items[0].quantity, 2)
        
        # Assert response totals
        cart_totals = response.json()
        self.assertEqual(cart_totals['cart_count'], 2)
        self.assertEqual(cart_totals['total_price'], Decimal('100.00'))  # 2 * 50.00

    def test_transfer_cart_on_login_signal(self):
        """
        Test that `transfer_cart_on_login` transfers session-based cart items to user on login.
        """
        # Add an item to the cart with session key (simulating an unauthenticated user)
        session_key = self.client.session.session_key
        CartItem.objects.create(session_key=session_key, ticket_details=self.ticket_details, quantity=2)

        # Log out and then log back in to trigger the transfer
        self.client.logout()
        self.client.login(username='testuser', password='password')

        # Assert session-based cart items were transferred to the user's cart
        cart_items = CartItem.objects.filter(customer=self.customer)
        self.assertEqual(cart_items.count(), 1)
        self.assertEqual(cart_items[0].quantity, 2)

        # Check that session-based cart item no longer exists
        session_cart_items = CartItem.objects.filter(session_key=session_key)
        self.assertEqual(session_cart_items.count(), 0)
