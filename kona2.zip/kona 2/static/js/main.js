document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchForm = document.querySelector('.form-inline');
    searchForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const query = searchForm.querySelector('input[type="search"]').value;
        window.location.href = `/events/search/?q=${query}`;
    });

    // Handle adding items to cart
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const ticketId = this.dataset.ticketId;
            const quantity = this.dataset.quantity || 1;
            addToCart(ticketId, quantity);
        });
    });

    function addToCart(ticketId, quantity) {
        fetch(`/cart/add/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken(),
            },
            body: JSON.stringify({ ticket_id: ticketId, quantity: quantity })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Ticket added to cart successfully!');
            } else {
                alert('There was an error adding the ticket to the cart.');
            }
        });
    }

    function getCSRFToken() {
        return document.querySelector('input[name="csrfmiddlewaretoken"]').value;
    }

    // Additional JS for enhanced user experience
    // e.g., dynamic filters, calendar view interactions
});
