from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from event.views import event_list
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from .views import about,terms,privacy,ticket_agreement,disclaimer,cart_item_count_view
from markdownx import urls as markdownx_urls

urlpatterns = [
    path('', event_list, name='list'),
    path('admin/', admin.site.urls),
    path('event/', include('event.urls')),
    path('organiser/', include('organiser.urls')),
    path('ticket/', include('ticket.urls')),
    path('cart/', include('cart.urls')),
    #path('debtor/', include('debtor.urls')),
    path('customer/',include('customer.urls')),
    path('blog/',include('blog.urls')),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('linkup/about/', about, name='about'),
    path('linkup/privacy-policy/', privacy, name='privacy'),
    path('linkup/terms-of-service/',terms,name='terms'),
    path('linkup/ticker-agreement/',ticket_agreement,name='ticket_agreement'),
    path('linkup/disclaimer/',disclaimer,name='disclaimer'),
    path('cart-item-count/', cart_item_count_view, name='cart_item_count'),
    path('markdownx/', include(markdownx_urls)),

  
  
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

