from django.urls import path
from . import views

app_name = 'customer'

urlpatterns = [
    path('customer/register/', views.customer_registration, name='register'),
    path('customer/registration-complete/', views.registration_complete, name='registration_complete'),
    path('customer/dashboard/', views.customer_dashboard_view, name='dashboard'),
    path('customer/profile/', views.customer_profile, name='profile'),
    path('customer/profile/edit/', views.edit_customer_profile, name='edit_profile'),
    path('customer/login/', views.login_view, name='login'),
    path('customer/logout/', views.logout_view, name='logout'),
    path('customer/my_tickets/', views.my_tickets, name='my_tickets'),
    path('customer/cancel/my_tickets/<int:ticket_holder_id>/', views.cancel_ticket, name='cancel_ticket'),
    path('canceled-tickets/', views.canceled_tickets, name='canceled_tickets'),
    path('attended-events/', views.attended_events_view, name='attended'),
    path('settings/update_preferences/', views.update_preferences, name='update_preferences'),
    #path('api/customer-dashboard/', views.CustomerDashboardView.as_view(), name='customer_dashboard'),
    path('verify-email/<uidb64>/<token>/', views.verify_email, name='verify_email'),
    path('email-notice/',views.verify_email_notice,name='email_notice'),
    path("rewards-info/", views.rewards_explanation_view, name="reward_explanation"),
    path("reward-dashboard/", views.combined_rewards_dashboard_view, name="customer_rewards"),
    path('redeem-points/', views.redeem_points_view, name='redeem_points'),


]