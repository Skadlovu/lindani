from django import forms
from.models import Customer
from event.models import Event
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

class RedeemPointsForm(forms.Form):
    points = forms.IntegerField(min_value=1, required=True, label="Points to Redeem")


class PreferencesForm(forms.ModelForm):
    categories = forms.ModelMultipleChoiceField(
        queryset=Event.objects.values_list('category', flat=True).distinct(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )
    max_price = forms.IntegerField(
        widget=forms.NumberInput(attrs={'type': 'range', 'min': '0', 'max': '1000', 'step': '50'}),
        required=False
    )
    email_notifications = forms.BooleanField(required=False)
    sms_notifications = forms.BooleanField(required=False)
    push_notifications = forms.BooleanField(required=False)

    class Meta:
        model = Customer
        fields = ['categories', 'max_price', 'email_notifications', 'sms_notifications', 'push_notifications']





class CustomerInfoForm(forms.Form):
    name = forms.CharField(max_length=100)
    surname = forms.CharField(max_length=100)
    phone = forms.CharField(max_length=20)
    email = forms.EmailField()


class CustomerEmailForm(forms.ModelForm):
    class Meta:
        model=User
        fields=['username','email']

    def __init__(self, *args, **kwargs):
        super(CustomerEmailForm, self).__init__(*args, **kwargs)
        # Remove the help text from the password fields
        self.fields['username'].help_text = None



class CustomerProfileForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['first_name','last_name', 'cellphone_number', 'profile_picture']



class CustomerRegistrationForm(forms.ModelForm):
    email = forms.EmailField(required=True)
    password1 = forms.CharField(
        label="Password",
        widget=forms.PasswordInput,
        required=True
    )
    password2 = forms.CharField(
        label="Password confirmation",
        widget=forms.PasswordInput,
        required=True
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def __init__(self, *args, **kwargs):
        super(CustomerRegistrationForm, self).__init__(*args, **kwargs)
        # Remove the help text from the password fields
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None

        # Ensure no additional fields or messages are included
        for field_name in self.fields:
            self.fields[field_name].help_text = None  # Remove help text
            self.fields[field_name].label_suffix = ''  # Optional: remove colon after labels

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')

        if password1 and password2 and password1 != password2:
            raise ValidationError("Passwords do not match.")

        return cleaned_data

    def save(self, commit=True):
        # Save the User instance
        user = super(CustomerRegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.set_password(self.cleaned_data['password1'])  # Hash the password

        if commit:
            user.save()
        return user