from rest_framework import serializers
from .models import Customer

class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = [
            'first_name', 'last_name', 'total_spent',
            
        ]

from rest_framework import serializers
from .models import Customer, LoyaltyActivity, LoyaltyTier, LoyaltyMilestone

class CustomerSerializer(serializers.ModelSerializer):
    """Serializer for Customer model with current points and tier information"""
    current_tier = serializers.SerializerMethodField()
    points_to_next_tier = serializers.SerializerMethodField()
    
    class Meta:
        model = Customer
        fields = [
            'id', 'total_points', 'current_tier',
            'points_to_next_tier', 'date_joined', 'last_event_viewed','first_name', 'last_name', 'total_spent'
        ]
    
    def get_current_tier(self, obj):
        """Get the customer's current loyalty tier"""
        current_tier = LoyaltyTier.objects.filter(
            required_points__lte=obj.total_points,
            is_active=True
        ).order_by('-required_points').first()
        
        if current_tier:
            return {
                'name': current_tier.name,
                'benefits': current_tier.benefits
            }
        return None
    
    def get_points_to_next_tier(self, obj):
        """Calculate points needed for next tier"""
        next_tier = LoyaltyTier.objects.filter(
            required_points__gt=obj.total_points,
            is_active=True
        ).order_by('required_points').first()
        
        if next_tier:
            return next_tier.required_points - obj.total_points
        return None

class LoyaltyActivitySerializer(serializers.ModelSerializer):
    """Serializer for loyalty activities with customer details"""
    customer_email = serializers.EmailField(source='customer.email', read_only=True)
    
    class Meta:
        model = LoyaltyActivity
        fields = [
            'id', 'customer', 'customer_email', 'points',
            'activity_type', 'description', 'created_at',
            'expiry_date'
        ]
        read_only_fields = ['created_at']
    
    def validate(self, data):
        """Validate activity data"""
        if data.get('points', 0) <= 0:
            raise serializers.ValidationError(
                "Points must be a positive number"
            )
        
        if data.get('expiry_date') and data['expiry_date'] <= data.get('created_at'):
            raise serializers.ValidationError(
                "Expiry date must be after creation date"
            )
        
        return data

class LoyaltyTierSerializer(serializers.ModelSerializer):
    """Serializer for loyalty tiers with benefit validation"""
    class Meta:
        model = LoyaltyTier
        fields = [
            'id', 'name', 'required_points', 'benefits',
            'icon', 'description', 'is_active'
        ]
    
    def validate_benefits(self, value):
        """Validate the benefits JSON structure"""
        required_keys = {
            'early_access_minutes',
            'point_multiplier',
            'cancellation_hours',
            'priority_support',
            'exclusive_events',
            'reward_discount'
        }
        
        if not all(key in value for key in required_keys):
            raise serializers.ValidationError(
                f"Benefits must contain all required fields: {required_keys}"
            )
        
        if not isinstance(value['point_multiplier'], (int, float)):
            raise serializers.ValidationError(
                "Point multiplier must be a number"
            )
            
        if value['point_multiplier'] < 1:
            raise serializers.ValidationError(
                "Point multiplier cannot be less than 1"
            )
            
        return value

class MilestoneSerializer(serializers.ModelSerializer):
    """Serializer for loyalty milestones with achievement tracking"""
    achievement_count = serializers.SerializerMethodField()
    
    class Meta:
        model = LoyaltyMilestone
        fields = [
            'id', 'name', 'description', 'points_reward',
            'milestone_type', 'threshold', 'is_repeatable',
            'is_active', 'achievement_count'
        ]
    
    def get_achievement_count(self, obj):
        """Get the number of times this milestone has been achieved by customers"""
        # This assumes you have a related model tracking achievements
        # You would need to implement this based on your achievement tracking logic
        return obj.achievements.count() if hasattr(obj, 'achievements') else 0
    
    def validate(self, data):
        """Validate milestone data"""
        if data.get('points_reward', 0) <= 0:
            raise serializers.ValidationError(
                "Points reward must be a positive number"
            )
            
        if data.get('threshold', 0) <= 0:
            raise serializers.ValidationError(
                "Threshold must be a positive number"
            )
            
        return data