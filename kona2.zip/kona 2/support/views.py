# views.py
from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib import messages


